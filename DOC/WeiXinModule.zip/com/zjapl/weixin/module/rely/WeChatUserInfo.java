package com.zjapl.weixin.module.rely;

/**
 * 微信用户信息
 * @author yangb
 *
 */
public class WeChatUserInfo {

	private String state;
	
	private String openid;
	
	private WeiXinUser user;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public WeiXinUser getUser() {
		return user;
	}

	public void setUser(WeiXinUser user) {
		this.user = user;
	}
	
	
	
}
