package com.zjapl.weixin.module.rely;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import com.zjapl.weixin.module.ctrl.Config;

/**
 * @author yangb
 *
 */
@Service
public class WeiXinModuleService {

	/**
	 * 获取jsAPI授权参数
	 * @param url
	 * @return
	 */
	public String jsAPIconfig(String url){
		HashMap<String,String> map = new HashMap<>();
		map.put("url", url);
		map.put("appid", Config.APPID);
		System.err.println(map);
		String serverUrl = Config.SERVER_URL + "/public/web/jsconfig";
		String json = HttpHelper.post(serverUrl, map);
		return json;
	}
	
	/**
	 * 为用户绑定标签
	 * @param openid
	 * @param tagid
	 * @return
	 */
	public String batchTag(String openid, String tagid){
		HashMap<String,String> map = new HashMap<>();
		map.put("openid", openid);
		map.put("tagid", tagid);
		map.put("appid", Config.APPID);
		String serverUrl = Config.SERVER_URL + "/public/others/batchTag";
		String json = HttpHelper.post(serverUrl, map);
		return json;
	}
}
