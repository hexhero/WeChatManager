package com.zjapl.weixin.module.ctrl;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.zjapl.common.result.ObjectResultEx;
import com.zjapl.common.result.ResultEx;
import com.zjapl.office.dict.OfficeDict;
import com.zjapl.office.entity.OfficeUser;
import com.zjapl.office.service.IAuthService;
import com.zjapl.weixin.module.rely.WeiXinModuleService;
import com.zjapl.weixin.module.rely.WeiXinUser;

/**
 * 接受微信统一平台数据请求
 * @author yangb
 *
 */
@Controller
@RequestMapping("/public/wechat")
public class WeChatTransferController {
	
	@Autowired
	private WeiXinModuleService moduleServ;
	
	@Autowired
	private IAuthService authServ;
	
	/**
	 * 微信授权重定向的URL
	 * @param openid  微信用户的openid
	 * @param state   配置的state参数
	 * @param data    用户的个人信息 json格式
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/auth", method=RequestMethod.GET)
	public ModelAndView auth(String openid, String state, String data, HttpSession session){
		WeiXinUser user = JSON.parseObject(data, WeiXinUser.class); //将data 解析成用户数据, 如果Scope为base, data是空

		session.setAttribute("openid", openid);
		session.setAttribute("state", state);
		session.setAttribute("user", user);
		
		ModelAndView mv = new ModelAndView("index");

		return mv;
	}
	
	
	
	/**
	 * 这个Controller 由页面的JS框架访问, 不需要动它.
	 * 微信JsApi签名等等参数的初始化, 例如需要在页面中打开用户相册, 打开摄像头, 分享到朋友圈等等功能的时候, 详见https://mp.weixin.qq.com/wiki JS-SDK说明文档
	 * @param url
	 * @return
	 */
	@RequestMapping(value="/jsconfig")
	@ResponseBody
	public String jsconfig(String url){
		return moduleServ.jsAPIconfig(url);
	}
	
}
