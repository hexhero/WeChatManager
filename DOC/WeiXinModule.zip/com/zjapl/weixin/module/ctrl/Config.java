package com.zjapl.weixin.module.ctrl;

/**
 * 微信公众号配置信息
 * @author yangb
 *
 */
public class Config {

	/**
	 * 当前公众号的Appid
	 */
	public static final String APPID = "wx4f4707d0ed5a9332"; 
	
	/**
	 * 管理平台的Url地址
	 */
	public static final String SERVER_URL = "http://itapl.com/weixin-web";
}
